package com.bank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.support.SessionStatus;

import com.bank.entity.Payee;
import com.bank.entity.User;
import com.bank.service.BankService;
import com.bank.service.IBankService;

@Controller
public class BankController {
	static long accId;
	@Autowired
    IBankService bankService;
	int userId;
     
    @RequestMapping(method = RequestMethod.GET)
    public String setupForm(Model model)
    {
         Payee payee = new Payee();
         model.addAttribute("payee", payee);
         return "AddBeneficiaries";
    }
     
    @RequestMapping(method = RequestMethod.POST)
    public String submitForm(@ModelAttribute("employee") Payee payee,
                            BindingResult result, SessionStatus status)
    {
    	bankService=new BankService();
        bankService.addBeneficiary(payee);
        status.setComplete();
        return "redirect:AddBeneficiaries/success";
    }
     
    @RequestMapping(value = "/success", method = RequestMethod.GET)
    public String success(Model model)
    {
         return "AddBeneficiarySuccess";
    }
    
    @RequestMapping(value="/serviceTracker")
    public String  showaccountbalance(Model model){
  	 model.addAttribute("accountNumber",accId);
  	model.addAttribute("self",new User());
  	model.addAttribute("listSelfAccountID",bankService.selfAccountList(userId));
		return "PaymentServices";
    }
}


