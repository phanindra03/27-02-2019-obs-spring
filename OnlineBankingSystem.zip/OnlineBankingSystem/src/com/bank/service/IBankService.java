package com.bank.service;

import java.util.List;

import com.bank.entity.Payee;
import com.bank.entity.User;

public interface IBankService {

	void addBeneficiary(Payee payee);

	List<User> selfAccountList(int userId);

}
