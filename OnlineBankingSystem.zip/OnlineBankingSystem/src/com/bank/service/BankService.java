package com.bank.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.dao.IBankRepository;
import com.bank.entity.Payee;
import com.bank.entity.User;

@Transactional
@Service
public class BankService implements IBankService{
@Autowired
private IBankRepository bankRepository;
	@Override
	public void addBeneficiary(Payee payee) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<User> selfAccountList(int userId) {
		
		return bankRepository.selfAccountList(userId);
	}

}
