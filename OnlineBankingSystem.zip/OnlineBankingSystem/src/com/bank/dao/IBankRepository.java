package com.bank.dao;

import java.util.List;

import com.bank.entity.Payee;
import com.bank.entity.User;


public interface IBankRepository {
	public abstract int retriveAccountNumber();
	public abstract List<Payee> retriveSelfAccountNumber();
	public abstract List<Payee> retriveOtherAccountNumber();
	public int addBeneficiary();
	public abstract int retrivePayerAccountBalance();
	public abstract List<User> selfAccountList(int userId);
	List<Payee> retriveSelfAccountNumber(int accountId);
	

}
