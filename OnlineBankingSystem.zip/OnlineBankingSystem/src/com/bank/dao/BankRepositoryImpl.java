package com.bank.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bank.entity.Payee;
import com.bank.entity.User;

@Repository
public class BankRepositoryImpl implements IBankRepository{

	@PersistenceContext
 EntityManager entitymanager;
	@Override
	public List<Payee> retriveSelfAccountNumber(int accountId) {
		TypedQuery<Payee> query = entitymanager.createQuery("SELECT h. FROM Payee_table h where h.nickname=accountId ", Payee.class);
		return query.getResultList();
		
	}
	@Override
	public int retriveAccountNumber() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public List<Payee> retriveSelfAccountNumber() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<Payee> retriveOtherAccountNumber() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public int addBeneficiary() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public int retrivePayerAccountBalance() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public List<User> selfAccountList(int userId) {
		TypedQuery<User> query1=entitymanager.createQuery("SELECT h FROM User h where h.userId=:puserId",User.class);
		return query1.getResultList();
	}

}
